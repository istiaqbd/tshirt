<div class="wrap aws-main" data-view="<?php echo $page; ?>">

	<h1><?php echo esc_html( $page_title ); ?></h1>