<?php

register_theme_directory( ABSPATH . 'wp-content/themes/' );